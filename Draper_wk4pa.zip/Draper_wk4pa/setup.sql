CREATE DATABASE IF NOT EXISTS sdc310_wk4pa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Run this script in phpMyAdmin as an administrator.
-- The ECPI account must already exist; this grant does not create or alter its password.
GRANT SELECT ON sdc310_wk4pa.* TO 'ecpi_user'@'localhost';

USE sdc310_wk4pa;
CREATE TABLE IF NOT EXISTS products (
    ProductNo INT NOT NULL AUTO_INCREMENT,
    Name VARCHAR(50) NOT NULL,
    Type VARCHAR(50) NOT NULL,
    PRIMARY KEY (ProductNo)
);

INSERT INTO products (Name, Type) VALUES
('Nintendo Switch', 'Console'),
('PlayStation 5', 'Console'),
('The Legend of Zelda', 'Video Game'),
('Xbox Wireless Controller', 'Accessory'),
('Pikachu Figurine', 'Collectible');
