<?php
require_once __DIR__ . '/controllers/ProductController.php';

try {
    show_products();
} catch (Throwable $error) {
    http_response_code(500);
    error_log($error);
    echo '<h1>Unable to load products</h1><p>Check the database setup and connection settings.</p>';
}
