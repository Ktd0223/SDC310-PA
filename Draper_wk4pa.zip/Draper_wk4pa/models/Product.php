<?php
require_once __DIR__ . '/../config/database.php';

function get_all_products(): array
{
    $connection = get_db_connection();
    try {
        $result = $connection->query('SELECT ProductNo, Name, Type FROM products ORDER BY ProductNo');
        if ($result === false) {
            throw new RuntimeException('Could not load products: ' . $connection->error);
        }
        return $result->fetch_all(MYSQLI_ASSOC);
    } finally {
        $connection->close();
    }
}
