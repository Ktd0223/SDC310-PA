<?php
require_once __DIR__ . '/../models/Product.php';

function show_products(): void
{
    $products = get_all_products();
    require __DIR__ . '/../views/products.php';
}
