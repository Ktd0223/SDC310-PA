SDC310 Week 4 Performance Assessment — Kai Draper

1. Start Apache and MySQL in XAMPP.
2. Copy the Draper_wk4pa folder to C:\xampp\htdocs\Draper_wk4pa.
3. Visit http://localhost/phpmyadmin and import setup.sql as a MySQL administrator.
   If ecpi_user does not exist, create the account first in phpMyAdmin User accounts.
   The script grants read access to this database to ecpi_user@localhost.
4. Confirm the password in config/database.php matches your existing ecpi_user password.
5. Open http://localhost/Draper_wk4pa/ in your browser.
6. In phpMyAdmin, capture the products Structure tab (all three columns) and Browse tab (five rows).
7. Capture the application page showing the product table. Add the screenshots to the supplied Word document.

MVC: index.php routes to controllers/ProductController.php; models/Product.php reads MySQL; views/products.php displays all product fields.
Running setup.sql a second time adds five more sample rows. Import it once.
