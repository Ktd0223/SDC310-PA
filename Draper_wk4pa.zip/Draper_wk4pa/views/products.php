<?php
function escape_html($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kai Draper Wk 4 Performance Assessment</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 2.5rem auto; max-width: 900px; padding: 0 1rem; color: #17243a; }
        h1 { margin-bottom: .25rem; }
        p { color: #526074; }
        table { border-collapse: collapse; width: 100%; margin-top: 1.5rem; }
        th, td { padding: .85rem 1rem; border: 1px solid #cbd5e1; text-align: left; }
        th { background: #17365d; color: white; }
        tbody tr:nth-child(even) { background: #f3f6fa; }
    </style>
</head>
<body>
    <h1>Product Catalog</h1>
    <p>Products stored in the sdc310_wk4pa database</p>
    <table>
        <thead><tr><th>ProductNo</th><th>Name</th><th>Type</th></tr></thead>
        <tbody>
        <?php foreach ($products as $product): ?>
            <tr>
                <td><?= escape_html($product['ProductNo']) ?></td>
                <td><?= escape_html($product['Name']) ?></td>
                <td><?= escape_html($product['Type']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if ($products === []): ?>
            <tr><td colspan="3">No products found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
