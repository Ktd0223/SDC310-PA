<?php
function get_db_connection(): mysqli
{
    $host = 'localhost';
    $username = 'ecpi_user';
    $password = 'Password1'; // Change if your local ecpi_user password differs.
    $database = 'sdc310_wk4pa';

    $connection = new mysqli($host, $username, $password, $database);
    if ($connection->connect_error) {
        throw new RuntimeException('Database connection failed: ' . $connection->connect_error);
    }
    $connection->set_charset('utf8mb4');
    return $connection;
}
